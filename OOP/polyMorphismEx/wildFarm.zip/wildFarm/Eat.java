package wildFarm;

public interface Eat {
    void eat(Food food);
}
