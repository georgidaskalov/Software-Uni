package wildFarm;

public abstract class Felime extends Mammal {
    Felime(String animalName, String animalType, double animalWeight,  String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }
}
