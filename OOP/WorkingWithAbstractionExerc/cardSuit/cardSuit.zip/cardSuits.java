

import java.util.Scanner;

public enum cardSuits {
    CLUBS("CLUBS",0),
    DIAMONDS("DIAMONDS",1),
    HEARTS("HEARTS",2),
    SPADES("SPADES",3);
    private String name;
    private int number;
    cardSuits(String name, int number) {
        this.name = name;
        this.number = number;
    }



}
