

public enum CardRank {
    ACE("ACE", 0),
    TWO("TWO", 1),
    THREE("THREE", 2),
    FOUR("FOUR", 3),
    FIVE("FIVE", 4),
    SIX("SIX", 5),
    SEVEN("SEVEN", 6),
    EIGHT("EIGHT", 7),
    NINE("NINE", 8),
    TEN("TEN", 9),
    JACK("JACK", 10),
    QUEEN("QUEEN", 11),
    KING("KING", 12);

    private String name;
    private int ordinal;

    CardRank(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }
}
