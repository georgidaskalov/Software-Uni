package Person;

public class Child extends Person {
    private String name;
    private int age;

    public Child(String name, int age) {
        super(name, age);
    }
}
