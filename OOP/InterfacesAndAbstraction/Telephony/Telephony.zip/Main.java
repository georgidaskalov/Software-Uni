
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String line = scanner.nextLine();
        String[] phoneNumbers = line.split("\\s+");
        List<String> numbers = new ArrayList<>();
        numbers.addAll(Arrays.asList(phoneNumbers));

        String urlLine = scanner.nextLine();
        String numValidation = "^[0-9]+$";

        for (String number : numbers) {
            if (!number.matches(numValidation)) {
                System.out.println("Invalid number!");
            }else {
                System.out.println("Calling... " + number);
            }
        }
        String validation = "[^-?0-9]+";
        String[] urlInput = urlLine.split("\\s+");
        List<String> urls = new ArrayList<>();
        for (String s : urlInput) {
            if (!s.matches(validation)){
                System.out.println("Invalid URL!");
            }else {
                urls.add(s);
                System.out.println("Browsing: "+ s + "!");
            }
        }
        Smartphone smartphone = new Smartphone(numbers , urls);


    }
}
