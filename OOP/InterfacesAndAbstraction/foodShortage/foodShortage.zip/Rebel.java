
public class Rebel extends AbstractCitizen {
    private String group;
    private int food;


    public Rebel(String name, int age, String group) {
        super(name ,age);
        this.group = group;
    }
    public String getGroup(){
        return this.group;
    }



    @Override
    public void buyFood() {
        this.addFood(5);
    }
}
