package classBox;


public class Box {
    private double length;
    private double width;
    private double height;

    public  Box(double length, double width, double height) {
        setLength(length);
        setWidth(width);
        setHeight(height);

    }

    // a*b*c
    public double calculateVolume() {
        double result = this.length * this.height * this.width;
        return result;
    }

    //a * c * 2 + b * c * 2
    public double calculateLateralSurfaceArea() {
        double result = this.length * this.height * 2 + this.width * this.height * 2;
        return result;
    }

    // 2 * a * b + 2 * a * c + 2 * b * c
    public double calculateSurfaceArea() {
        double result = 2 * this.length * this.width + 2 * this.length *
                this.height + 2 * this.width * this.height;
        return result;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        if (length <= 0){
            throw new IllegalArgumentException("Length cannot be zero or negative.");
        }
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        if (width <= 0){
            throw new IllegalArgumentException("Width cannot be zero or negative.");
        }
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height <= 0){
            throw new IllegalArgumentException("Height cannot be zero or negative.");
        }
        this.height = height;
    }

}
